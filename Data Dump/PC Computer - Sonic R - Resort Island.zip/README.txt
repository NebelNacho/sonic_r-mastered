Resort Island from Sonic R ripped by InvisibleUp
=================================================================
Use this for whatever, no credit needed, but don't claim this as your own rip.

This is the entirety of Resort Island from Sonic R, including Sonic tokens and balloons.

Everything is precisely where it was located in the game. (In fact, besides adding the
floor and setting the textures, this is literally a direct rip.)

It is, however, missing some things like vertex colors (which makes the track more colorful
and actually shaded in-game), ring locations, player start locations, etc. due to the
limitations of the OBJ format.

If you have questions, etc. just post on the Models Resource page and I'll try to
get back to you.